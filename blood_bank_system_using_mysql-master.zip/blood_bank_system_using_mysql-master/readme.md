# Blood Bank System :-
This is a Blood Bank System Website made using HTML and MySQL.
Front-end is made using HTML, CSS and Java-Script.
Back-end is made using MySQL.

Firstly, you have to download xampp software on your system.
Then, you have to copy paste your whole project to htdocs folder to xampp.
Then, simply run local server and mysql server and then type "localhost/index.html" in browser.
